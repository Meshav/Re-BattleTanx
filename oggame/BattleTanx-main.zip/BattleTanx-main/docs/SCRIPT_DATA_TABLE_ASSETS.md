# Script and data-table assets (ROM 0x101000..0x800000)

Result: the asset region holds **no independent script or data-table asset**.
The "Scripts and data tables" report category is 0 bytes because nothing in the
region is proven to be one. No bytes were relabelled.

## Method

1. **PI references from program data.** `battletanx_assets.asset_region_pi_references`
   scans every aligned big-endian word of the initialized program image
   (ROM 0x1000..0xD7040, VRAM 0x80071000..) for cartridge addresses
   0xB0101000..0xB0800000. It finds 123 words. Each one lands in a parser-owned
   run (images: 99, music: 19, animations: 1), or on one of four documented
   boundaries:

   | Target | Referenced by | Meaning |
   |---|---|---|
   | 0x2C19B0 | 0x80125760 | music sequence table end sentinel (the range itself is unreferenced) |
   | 0x7E3210 | 0x8014186C | briefing image table end |
   | 0x7E76D0 | 0x80141474 | level map record 9 end |
   | 0x7EA060 | 0x8014153C | last level map end |

2. **PI constants in code.** All 136 `D_B0xxxxxx` symbols in `asm/us` and `src`
   resolve to the same parsed categories (images, levels, navigation, music,
   animations, fonts, sound containers, models, textures). The rest are stream end
   addresses that fall on padding, or the same four boundaries as above. Level
   stream addresses are stored as code constants by func_800865E0, not as data words.
3. **Containers.** The decoded entries of every resource bundle
   (`tools/asset_inventory/bundle_entries.py`), world stream and navigation stream
   (`level_sections.py`) were checked against their consumers:
   - **World stream sections** are level geometry and placement records. All nine
     are consumed only by func_80088CF0 (`load_level_resources`), so they stay
     under "levels".
   - **Navigation streams** are vertex, triangle and kind tables read by the
     func_800DDA08 / 800E0xxx path ("navigation").
   - **Demo recordings** (0x319B30..0x3D16D0) are per-frame camera matrices and
     input records replayed by func_800EC410 / func_800EC7A8 ("animations and
     recordings").

## Text inside strip bundles (not scripts)

Entries 3 and 4 of each of the ten strip bundles (the PI table at
`RESOURCE_BUNDLE_STRIP_TABLE`) are ASCII text:
- **Entry 3** is a faction description with CRLF lines.
- **Entry 4** is a unit roster.

There is no reader of offset words +0x10 or +0x14:
- **Entry 3:** the unit-select screen (func_800C5C60, `draw_unit_select_screen.c`)
  draws the faction text through the program-data pointer table D_80134960, whose
  first entry is VRAM 0x801340A8 (ROM 0xC40A8). That copy has LF line breaks,
  different wrapping, and edited wording in places ("above ground" becomes
  "above"). Seven of the ten bundles carry the same "Decay" text.
- **Entry 4:** the roster text does not occur in the program image at all.

These bytes stay as `unknown` entries inside an image-bundle payload. They are
text, not script, and are not consumed.

## Remaining uncertainty

- **Program-image tables.** Data tables that live inside the program image
  (unit stats, string pointer tables, level index lists) are outside the asset
  region. They are accounted for by `data_ledger.py`.
- **Computed addresses.** A ROM address built at run time from unrelated
  constants would not be seen by either scan. None is known; the remaining
  `unused` rows list what evidence would change them.
- **0x2C19B0..0x2C3E50.** This range (count 4 plus an offset table, data
  resembling RGBA5551) has no consumer. It stays `unused` rather than becoming a
  data table.

## Regression guard

`tests/test_battletanx_assets.py` has two guards:
- **`test_asset_region_references_have_no_script_table_target`** fails if a new
  program-data reference points at a range the ledger does not own.
- **`test_strip_bundle_text_has_a_program_image_revision`** pins the text
  evidence above.

Both need the base ROM and are skipped without it.
